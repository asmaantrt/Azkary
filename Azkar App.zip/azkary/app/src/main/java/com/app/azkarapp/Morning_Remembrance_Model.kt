package com.app.azkarapp

data class Morning_Remembrance_Model(var text: String , var count : String , var title : String ){

}

